--
-- PostgreSQL database dump
--

\restrict FAEtOn4XZOfM8LQhCmmHrTEYBigBdtjB1HTtTjY6JfzCMTxur1OnRcdzEvaedmc

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Type: SCHEMA; Schema: -; Owner: aymeric
--

CREATE SCHEMA "9eb5427c-9a67-40da-a9da-f04b8a2aa38b";


ALTER SCHEMA "9eb5427c-9a67-40da-a9da-f04b8a2aa38b" OWNER TO aymeric;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".ar_internal_metadata OWNER TO aymeric;

--
-- Name: footnotes; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes (
    id bigint NOT NULL,
    line_id bigint NOT NULL,
    code character varying,
    label character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    checksum character varying,
    checksum_source text,
    data_source_ref character varying
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes OWNER TO aymeric;

--
-- Name: footnotes_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_id_seq OWNER TO aymeric;

--
-- Name: footnotes_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes.id;


--
-- Name: footnotes_vehicle_journeys; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_vehicle_journeys (
    vehicle_journey_id bigint NOT NULL,
    footnote_id bigint NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_vehicle_journeys OWNER TO aymeric;

--
-- Name: journey_patterns; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    objectid character varying NOT NULL,
    object_version bigint,
    name character varying,
    registration_number character varying,
    published_name character varying,
    departure_stop_point_id bigint,
    arrival_stop_point_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    checksum character varying,
    checksum_source text,
    data_source_ref character varying,
    costs jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    custom_field_values jsonb,
    shape_id bigint,
    booking_arrangement_id bigint
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns OWNER TO aymeric;

--
-- Name: journey_patterns_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_id_seq OWNER TO aymeric;

--
-- Name: journey_patterns_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns.id;


--
-- Name: journey_patterns_stop_points; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points (
    journey_pattern_id bigint NOT NULL,
    stop_point_id bigint NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points OWNER TO aymeric;

--
-- Name: referential_codes; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes (
    id bigint NOT NULL,
    code_space_id bigint NOT NULL,
    resource_type character varying NOT NULL,
    resource_id bigint NOT NULL,
    value character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes OWNER TO aymeric;

--
-- Name: referential_codes_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes_id_seq OWNER TO aymeric;

--
-- Name: referential_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes.id;


--
-- Name: routes; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes (
    id bigint NOT NULL,
    line_id bigint NOT NULL,
    objectid character varying NOT NULL,
    object_version bigint,
    name character varying,
    opposite_route_id bigint,
    published_name character varying,
    wayback character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    checksum character varying,
    checksum_source text,
    data_source_ref character varying,
    metadata jsonb
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes OWNER TO aymeric;

--
-- Name: routes_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes_id_seq OWNER TO aymeric;

--
-- Name: routes_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes.id;


--
-- Name: routing_constraint_zones; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    objectid character varying NOT NULL,
    object_version bigint,
    route_id bigint NOT NULL,
    stop_point_ids bigint[],
    checksum character varying,
    checksum_source text,
    data_source_ref character varying,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones OWNER TO aymeric;

--
-- Name: routing_constraint_zones_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones_id_seq OWNER TO aymeric;

--
-- Name: routing_constraint_zones_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".schema_migrations OWNER TO aymeric;

--
-- Name: service_counts; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts (
    id bigint NOT NULL,
    journey_pattern_id bigint NOT NULL,
    route_id bigint NOT NULL,
    line_id bigint NOT NULL,
    date date NOT NULL,
    count integer DEFAULT 0 NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts OWNER TO aymeric;

--
-- Name: service_counts_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts_id_seq OWNER TO aymeric;

--
-- Name: service_counts_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts.id;


--
-- Name: stop_points; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    stop_area_id bigint NOT NULL,
    objectid character varying NOT NULL,
    object_version bigint,
    "position" integer NOT NULL,
    for_boarding character varying,
    for_alighting character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    flexible boolean DEFAULT false NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points OWNER TO aymeric;

--
-- Name: stop_points_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points_id_seq OWNER TO aymeric;

--
-- Name: stop_points_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points.id;


--
-- Name: time_table_dates; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates (
    id bigint NOT NULL,
    time_table_id bigint NOT NULL,
    date date,
    in_out boolean,
    checksum character varying,
    checksum_source text
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates OWNER TO aymeric;

--
-- Name: time_table_dates_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates_id_seq OWNER TO aymeric;

--
-- Name: time_table_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates.id;


--
-- Name: time_table_periods; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods (
    id bigint NOT NULL,
    time_table_id bigint NOT NULL,
    period_start date,
    period_end date,
    checksum character varying,
    checksum_source text
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods OWNER TO aymeric;

--
-- Name: time_table_periods_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods_id_seq OWNER TO aymeric;

--
-- Name: time_table_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods.id;


--
-- Name: time_tables; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables (
    id bigint NOT NULL,
    objectid character varying NOT NULL,
    object_version bigint DEFAULT 1,
    comment character varying,
    int_day_types integer DEFAULT 0,
    start_date date,
    end_date date,
    calendar_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    color character varying,
    created_from_id bigint,
    checksum character varying,
    checksum_source text,
    data_source_ref character varying,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables OWNER TO aymeric;

--
-- Name: time_tables_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_id_seq OWNER TO aymeric;

--
-- Name: time_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables.id;


--
-- Name: time_tables_vehicle_journeys; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys (
    time_table_id bigint NOT NULL,
    vehicle_journey_id bigint NOT NULL
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys OWNER TO aymeric;

--
-- Name: vehicle_journey_at_stops; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops (
    id bigint NOT NULL,
    vehicle_journey_id bigint NOT NULL,
    stop_point_id bigint NOT NULL,
    arrival_time time without time zone,
    departure_time time without time zone,
    departure_day_offset integer DEFAULT 0,
    arrival_day_offset integer DEFAULT 0,
    checksum character varying,
    checksum_source text,
    stop_area_id bigint,
    earliest_departure_time_of_day integer,
    latest_arrival_time_of_day integer
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops OWNER TO aymeric;

--
-- Name: vehicle_journey_at_stops_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops_id_seq OWNER TO aymeric;

--
-- Name: vehicle_journey_at_stops_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops.id;


--
-- Name: vehicle_journeys; Type: TABLE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    journey_pattern_id bigint NOT NULL,
    company_id bigint,
    objectid character varying NOT NULL,
    object_version bigint,
    transport_mode character varying,
    published_journey_name character varying,
    published_journey_identifier character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    checksum character varying,
    checksum_source text,
    data_source_ref character varying,
    custom_field_values jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    line_notice_ids bigint[] DEFAULT '{}'::bigint[],
    accessibility_assessment_id bigint,
    service_facility_set_ids bigint[] DEFAULT '{}'::bigint[]
);


ALTER TABLE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys OWNER TO aymeric;

--
-- Name: vehicle_journeys_id_seq; Type: SEQUENCE; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys_id_seq OWNER TO aymeric;

--
-- Name: vehicle_journeys_id_seq; Type: SEQUENCE OWNED BY; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER SEQUENCE "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys_id_seq OWNED BY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys.id;


--
-- Name: footnotes id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_id_seq'::regclass);


--
-- Name: journey_patterns id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_id_seq'::regclass);


--
-- Name: referential_codes id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes_id_seq'::regclass);


--
-- Name: routes id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes_id_seq'::regclass);


--
-- Name: routing_constraint_zones id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones_id_seq'::regclass);


--
-- Name: service_counts id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts_id_seq'::regclass);


--
-- Name: stop_points id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points_id_seq'::regclass);


--
-- Name: time_table_dates id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates_id_seq'::regclass);


--
-- Name: time_table_periods id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods_id_seq'::regclass);


--
-- Name: time_tables id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_id_seq'::regclass);


--
-- Name: vehicle_journey_at_stops id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops_id_seq'::regclass);


--
-- Name: vehicle_journeys id; Type: DEFAULT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys ALTER COLUMN id SET DEFAULT nextval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	test	2025-11-05 14:01:04.152982	2025-11-05 14:01:04.152988
\.


--
-- Data for Name: footnotes; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes (id, line_id, code, label, created_at, updated_at, checksum, checksum_source, data_source_ref) FROM stdin;
1	1	some_footnote	FootNote Label 1	2025-11-05 14:01:04.332988	2025-11-05 14:01:04.332988	\N	\N	\N
\.


--
-- Data for Name: footnotes_vehicle_journeys; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_vehicle_journeys (vehicle_journey_id, footnote_id) FROM stdin;
1	1
\.


--
-- Data for Name: journey_patterns; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns (id, route_id, objectid, object_version, name, registration_number, published_name, departure_stop_point_id, arrival_stop_point_id, created_at, updated_at, checksum, checksum_source, data_source_ref, costs, metadata, custom_field_values, shape_id, booking_arrangement_id) FROM stdin;
1	1	chouette:JourneyPattern:db2af8a8-85fb-4c0a-9851-29489b17c3e6:LOC	\N	some_journey_pattern	\N	\N	1	3	2025-11-05 14:01:04.72343	2025-11-05 14:01:04.814826	\N	\N	\N	{}	{}	{}	\N	\N
\.


--
-- Data for Name: journey_patterns_stop_points; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points (journey_pattern_id, stop_point_id) FROM stdin;
1	1
1	2
1	3
\.


--
-- Data for Name: referential_codes; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes (id, code_space_id, resource_type, resource_id, value, created_at, updated_at) FROM stdin;
1	1	Chouette::TimeTable	1	time_table_code	2025-11-05 14:01:04.430783	2025-11-05 14:01:04.430783
2	1	Chouette::Route	1	route_code	2025-11-05 14:01:04.475328	2025-11-05 14:01:04.475328
3	1	Chouette::JourneyPattern	1	journey_pattern_code	2025-11-05 14:01:04.826384	2025-11-05 14:01:04.826384
4	1	Chouette::VehicleJourney	1	vehicle_journey_code	2025-11-05 14:01:04.946995	2025-11-05 14:01:04.946995
\.


--
-- Data for Name: routes; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes (id, line_id, objectid, object_version, name, opposite_route_id, published_name, wayback, created_at, updated_at, checksum, checksum_source, data_source_ref, metadata) FROM stdin;
1	1	chouette:Route:ae567b20-c67e-461c-bbfa-375db5c2d859:LOC	\N	some_route	\N	\N	outbound	2025-11-05 14:01:04.473295	2025-11-05 14:01:04.473295	\N	\N	\N	\N
\.


--
-- Data for Name: routing_constraint_zones; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones (id, name, created_at, updated_at, objectid, object_version, route_id, stop_point_ids, checksum, checksum_source, data_source_ref, metadata) FROM stdin;
1	some_routing_constraint_zone	2025-11-05 14:01:05.024459	2025-11-05 14:01:05.024459	chouette:RoutingConstraintZone:b541bb1c-329e-43f4-bd70-8bbf1c0d5058:LOC	\N	1	{2,3}	\N	\N	\N	{}
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".schema_migrations (version) FROM stdin;
20251013075038
20250929122802
20250919094446
20250917090428
20250910060512
20250907060228
20250901160955
20250822093323
20250805131958
20250804095811
20250715143401
20250613122420
20250611103319
20250429195523
20250425132626
20250331140009
20250305102006
20250228103946
20250212100249
20250203141234
20250130164134
20250114150213
20250108083243
20250102094815
20250102094814
20241206144247
20241029071553
20241025100315
20241025093636
20241025085128
20241024084907
20241022074008
20241009075253
20241008065743
20241006192318
20240920050942
20240917152914
20240910171032
20240910103029
20240819135253
20240729152804
20240708070342
20240627133040
20240604133209
20240603124932
20240530091549
20240523070455
20240521100547
20240516133515
20240513083939
20240423123123
20240422122412
20240418122647
20240412123704
20240412090129
20240403205758
20240329155023
20240327111529
20240321122655
20240321121832
20240311134245
20240215110746
20240207144844
20240123161651
20240119151212
20231221181235
20231221174101
20231218161931
20231215150005
20231212134450
20231127151208
20231116161907
20231019081559
20230912100632
20230907104115
20230901121853
20230824140434
20230823134343
20230822153032
20230821131334
20230816202654
20230809150200
20230804083558
20230718115813
20230706084206
20230630103907
20230626101543
20230616085741
20230530144339
20230517140119
20230425130056
20230313133608
20230228132902
20230124150645
20230115084034
20221208073251
20221114153323
20221031134340
20221021065517
20221019153821
20221017104544
20220929095430
20220923134846
20220920203015
20220909074432
20220906100418
20220824165032
20220808124959
20220804092409
20220705065413
20220701085131
20220610094124
20220607174321
20220529090410
20220527074112
20220520131934
20220520131227
20220513084426
20220510083139
20220406200454
20220325152937
20220322153842
20220316101826
20220314163647
20220314111039
20220301144132
20220301144101
20220225141451
20220224095842
20220217083423
20220217073230
20220214140342
20220211095318
20220128083110
20220124151311
20220123204936
20220121161635
20220121161552
20220121151104
20220120135457
20220119182939
20220111154109
20220107120759
20211217073653
20211202142900
20211129091129
20211119102837
20211117172911
20211109154901
20211104104952
20211104104938
20211022073107
20211021112753
20211013064010
20210812144527
20210727144032
20210708085518
20210706093921
20210615142111
20210615125814
20210521122450
20210509170255
20210402130945
\.


--
-- Data for Name: service_counts; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts (id, journey_pattern_id, route_id, line_id, date, count) FROM stdin;
1	1	1	1	2025-02-04	0
\.


--
-- Data for Name: stop_points; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points (id, route_id, stop_area_id, objectid, object_version, "position", for_boarding, for_alighting, created_at, updated_at, metadata, flexible) FROM stdin;
1	1	1	chouette:StopPoint:d48d02be-69a2-4bd9-8670-1ea9a9f7a31b:LOC	\N	0	normal	normal	2025-11-05 14:01:04.619074	2025-11-05 14:01:04.619074	{"name": "stop_point1"}	f
2	1	2	chouette:StopPoint:9e5df929-9ca9-405a-8e08-1508686d89ca:LOC	\N	1	normal	normal	2025-11-05 14:01:04.641308	2025-11-05 14:01:04.641308	{"name": "stop_point2"}	f
3	1	3	chouette:StopPoint:562f3d67-ed57-428d-afb6-b3c340c3f9eb:LOC	\N	2	normal	normal	2025-11-05 14:01:04.664895	2025-11-05 14:01:04.664895	{"name": "stop_point3"}	f
\.


--
-- Data for Name: time_table_dates; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates (id, time_table_id, date, in_out, checksum, checksum_source) FROM stdin;
1	1	2024-12-13	t	\N	\N
2	1	2025-06-23	f	\N	\N
\.


--
-- Data for Name: time_table_periods; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods (id, time_table_id, period_start, period_end, checksum, checksum_source) FROM stdin;
1	1	2030-01-07	2030-01-20	\N	\N
\.


--
-- Data for Name: time_tables; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables (id, objectid, object_version, comment, int_day_types, start_date, end_date, calendar_id, created_at, updated_at, color, created_from_id, checksum, checksum_source, data_source_ref, metadata) FROM stdin;
1	chouette:TimeTable:4b917a8c-782d-4dda-b60f-7d0f5c66ade6:LOC	1	some_time_table	508	2024-12-13	2030-01-20	\N	2025-11-05 14:01:04.428832	2025-11-05 14:01:04.428832	\N	\N	\N	\N	\N	{}
\.


--
-- Data for Name: time_tables_vehicle_journeys; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys (time_table_id, vehicle_journey_id) FROM stdin;
1	1
\.


--
-- Data for Name: vehicle_journey_at_stops; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops (id, vehicle_journey_id, stop_point_id, arrival_time, departure_time, departure_day_offset, arrival_day_offset, checksum, checksum_source, stop_area_id, earliest_departure_time_of_day, latest_arrival_time_of_day) FROM stdin;
1	1	1	12:00:00	12:01:00	0	0	\N	\N	\N	\N	\N
2	1	2	12:05:00	12:06:00	0	0	\N	\N	\N	\N	\N
3	1	3	12:10:00	12:11:00	0	0	\N	\N	\N	\N	\N
\.


--
-- Data for Name: vehicle_journeys; Type: TABLE DATA; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

COPY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys (id, route_id, journey_pattern_id, company_id, objectid, object_version, transport_mode, published_journey_name, published_journey_identifier, created_at, updated_at, checksum, checksum_source, data_source_ref, custom_field_values, metadata, line_notice_ids, accessibility_assessment_id, service_facility_set_ids) FROM stdin;
1	1	1	\N	chouette:VehicleJourney:4dc78f6e-6e73-4314-bd1d-960c79facf55:LOC	\N	\N	some_vehicle_journey	\N	2025-11-05 14:01:04.943192	2025-11-05 14:01:04.943192	\N	\N	\N	{}	{}	{}	\N	{}
\.


--
-- Name: footnotes_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes_id_seq', 1, true);


--
-- Name: journey_patterns_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_id_seq', 1, true);


--
-- Name: referential_codes_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes_id_seq', 4, true);


--
-- Name: routes_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes_id_seq', 1, true);


--
-- Name: routing_constraint_zones_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones_id_seq', 1, true);


--
-- Name: service_counts_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts_id_seq', 1, true);


--
-- Name: stop_points_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points_id_seq', 3, true);


--
-- Name: time_table_dates_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates_id_seq', 2, true);


--
-- Name: time_table_periods_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods_id_seq', 1, true);


--
-- Name: time_tables_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_id_seq', 1, true);


--
-- Name: vehicle_journey_at_stops_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops_id_seq', 3, true);


--
-- Name: vehicle_journeys_id_seq; Type: SEQUENCE SET; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

SELECT pg_catalog.setval('"9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys_id_seq', 1, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: footnotes footnotes_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".footnotes
    ADD CONSTRAINT footnotes_pkey PRIMARY KEY (id);


--
-- Name: journey_patterns_stop_points index_unique_journey_patterns_stop_points; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points
    ADD CONSTRAINT index_unique_journey_patterns_stop_points UNIQUE (journey_pattern_id, stop_point_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stop_points index_unique_route_stop_points; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points
    ADD CONSTRAINT index_unique_route_stop_points UNIQUE (route_id, "position") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: vehicle_journey_at_stops index_vehicle_journey_at_stops_point_id; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops
    ADD CONSTRAINT index_vehicle_journey_at_stops_point_id UNIQUE (vehicle_journey_id, stop_point_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: journey_patterns journey_patterns_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns
    ADD CONSTRAINT journey_patterns_pkey PRIMARY KEY (id);


--
-- Name: referential_codes referential_codes_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes
    ADD CONSTRAINT referential_codes_pkey PRIMARY KEY (id);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (id);


--
-- Name: routing_constraint_zones routing_constraint_zones_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routing_constraint_zones
    ADD CONSTRAINT routing_constraint_zones_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: service_counts service_counts_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts
    ADD CONSTRAINT service_counts_pkey PRIMARY KEY (id);


--
-- Name: stop_points stop_points_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points
    ADD CONSTRAINT stop_points_pkey PRIMARY KEY (id);


--
-- Name: time_table_dates time_table_dates_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates
    ADD CONSTRAINT time_table_dates_pkey PRIMARY KEY (id);


--
-- Name: time_table_periods time_table_periods_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods
    ADD CONSTRAINT time_table_periods_pkey PRIMARY KEY (id);


--
-- Name: time_tables time_tables_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables
    ADD CONSTRAINT time_tables_pkey PRIMARY KEY (id);


--
-- Name: vehicle_journey_at_stops vehicle_journey_at_stops_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops
    ADD CONSTRAINT vehicle_journey_at_stops_pkey PRIMARY KEY (id);


--
-- Name: vehicle_journeys vehicle_journeys_pkey; Type: CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys
    ADD CONSTRAINT vehicle_journeys_pkey PRIMARY KEY (id);


--
-- Name: index_journey_pattern_id_on_journey_patterns_stop_points; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_journey_pattern_id_on_journey_patterns_stop_points ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points USING btree (journey_pattern_id);


--
-- Name: index_journey_patterns_on_checksum; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_journey_patterns_on_checksum ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns USING btree (checksum);


--
-- Name: index_journey_patterns_on_custom_field_values; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_journey_patterns_on_custom_field_values ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns USING gin (custom_field_values);


--
-- Name: index_journey_patterns_on_route_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_journey_patterns_on_route_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns USING btree (route_id);


--
-- Name: index_journey_patterns_on_shape_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_journey_patterns_on_shape_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns USING btree (shape_id);


--
-- Name: index_referential_codes_on_code_space_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_referential_codes_on_code_space_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes USING btree (code_space_id);


--
-- Name: index_referential_codes_on_resource_type_and_resource_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_referential_codes_on_resource_type_and_resource_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes USING btree (resource_type, resource_id);


--
-- Name: index_referential_codes_on_space_and_resource; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_referential_codes_on_space_and_resource ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes USING btree (code_space_id, resource_type, resource_id);


--
-- Name: index_referential_codes_on_space_resource_and_value; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX index_referential_codes_on_space_resource_and_value ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".referential_codes USING btree (code_space_id, resource_type, resource_id, value);


--
-- Name: index_routes_on_checksum; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_routes_on_checksum ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes USING btree (checksum);


--
-- Name: index_routes_on_line_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_routes_on_line_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes USING btree (line_id);


--
-- Name: index_stop_points_on_route_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_stop_points_on_route_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points USING btree (route_id);


--
-- Name: index_time_table_dates_on_time_table_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_table_dates_on_time_table_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates USING btree (time_table_id);


--
-- Name: index_time_table_periods_on_period_start_and_period_end; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_table_periods_on_period_start_and_period_end ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods USING btree (period_start, period_end);


--
-- Name: index_time_table_periods_on_time_table_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_table_periods_on_time_table_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods USING btree (time_table_id);


--
-- Name: index_time_tables_on_calendar_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_tables_on_calendar_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables USING btree (calendar_id);


--
-- Name: index_time_tables_on_created_from_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_tables_on_created_from_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables USING btree (created_from_id);


--
-- Name: index_time_tables_vehicle_journeys_on_time_table_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_tables_vehicle_journeys_on_time_table_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys USING btree (time_table_id);


--
-- Name: index_time_tables_vehicle_journeys_on_vehicle_journey_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_time_tables_vehicle_journeys_on_vehicle_journey_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys USING btree (vehicle_journey_id);


--
-- Name: index_vehicle_journey_at_stops_on_stop_area_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vehicle_journey_at_stops_on_stop_area_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops USING btree (stop_area_id);


--
-- Name: index_vehicle_journey_at_stops_on_stop_pointid; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vehicle_journey_at_stops_on_stop_pointid ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops USING btree (stop_point_id);


--
-- Name: index_vehicle_journeys_on_checksum; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vehicle_journeys_on_checksum ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys USING btree (checksum);


--
-- Name: index_vehicle_journeys_on_custom_field_values; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vehicle_journeys_on_custom_field_values ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys USING gin (custom_field_values);


--
-- Name: index_vehicle_journeys_on_journey_pattern_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vehicle_journeys_on_journey_pattern_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys USING btree (journey_pattern_id);


--
-- Name: index_vehicle_journeys_on_route_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vehicle_journeys_on_route_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys USING btree (route_id);


--
-- Name: index_vjas_on_vehicle_journey_id_and_stop_area_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX index_vjas_on_vehicle_journey_id_and_stop_area_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops USING btree (vehicle_journey_id, stop_area_id);


--
-- Name: journey_pattern_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX journey_pattern_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts USING btree (journey_pattern_id);


--
-- Name: journey_patterns_objectid_key; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX journey_patterns_objectid_key ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns USING btree (objectid);


--
-- Name: line_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX line_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts USING btree (line_id);


--
-- Name: route_id; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE INDEX route_id ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".service_counts USING btree (route_id);


--
-- Name: routes_objectid_key; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX routes_objectid_key ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes USING btree (objectid);


--
-- Name: stop_points_objectid_key; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX stop_points_objectid_key ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points USING btree (objectid);


--
-- Name: time_tables_objectid_key; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX time_tables_objectid_key ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables USING btree (objectid);


--
-- Name: uniq_date_per_time_table; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX uniq_date_per_time_table ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates USING btree (date, time_table_id);


--
-- Name: uniq_period_start_and_period_end_per_time_table; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX uniq_period_start_and_period_end_per_time_table ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods USING btree (period_start, period_end, time_table_id);


--
-- Name: vehicle_journeys_objectid_key; Type: INDEX; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

CREATE UNIQUE INDEX vehicle_journeys_objectid_key ON "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys USING btree (objectid);


--
-- Name: journey_patterns arrival_point_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns
    ADD CONSTRAINT arrival_point_fkey FOREIGN KEY (arrival_stop_point_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points(id) ON DELETE SET NULL;


--
-- Name: journey_patterns departure_point_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns
    ADD CONSTRAINT departure_point_fkey FOREIGN KEY (departure_stop_point_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points(id) ON DELETE SET NULL;


--
-- Name: journey_patterns jp_route_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns
    ADD CONSTRAINT jp_route_fkey FOREIGN KEY (route_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes(id) ON DELETE CASCADE;


--
-- Name: journey_patterns_stop_points jpsp_jp_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points
    ADD CONSTRAINT jpsp_jp_fkey FOREIGN KEY (journey_pattern_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns(id) ON DELETE CASCADE;


--
-- Name: journey_patterns_stop_points jpsp_stoppoint_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns_stop_points
    ADD CONSTRAINT jpsp_stoppoint_fkey FOREIGN KEY (stop_point_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points(id) ON DELETE CASCADE;


--
-- Name: routes route_opposite_route_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes
    ADD CONSTRAINT route_opposite_route_fkey FOREIGN KEY (opposite_route_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes(id);


--
-- Name: time_table_dates tm_date_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_dates
    ADD CONSTRAINT tm_date_fkey FOREIGN KEY (time_table_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables(id) ON DELETE CASCADE;


--
-- Name: time_table_periods tm_period_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_table_periods
    ADD CONSTRAINT tm_period_fkey FOREIGN KEY (time_table_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables(id) ON DELETE CASCADE;


--
-- Name: vehicle_journeys vj_jp_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys
    ADD CONSTRAINT vj_jp_fkey FOREIGN KEY (journey_pattern_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".journey_patterns(id) ON DELETE CASCADE;


--
-- Name: vehicle_journeys vj_route_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys
    ADD CONSTRAINT vj_route_fkey FOREIGN KEY (route_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".routes(id) ON DELETE CASCADE;


--
-- Name: vehicle_journey_at_stops vjas_sp_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops
    ADD CONSTRAINT vjas_sp_fkey FOREIGN KEY (stop_point_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".stop_points(id) ON DELETE CASCADE;


--
-- Name: vehicle_journey_at_stops vjas_vj_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journey_at_stops
    ADD CONSTRAINT vjas_vj_fkey FOREIGN KEY (vehicle_journey_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys(id) ON DELETE CASCADE;


--
-- Name: time_tables_vehicle_journeys vjtm_tm_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys
    ADD CONSTRAINT vjtm_tm_fkey FOREIGN KEY (time_table_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables(id) ON DELETE CASCADE;


--
-- Name: time_tables_vehicle_journeys vjtm_vj_fkey; Type: FK CONSTRAINT; Schema: 9eb5427c-9a67-40da-a9da-f04b8a2aa38b; Owner: aymeric
--

ALTER TABLE ONLY "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".time_tables_vehicle_journeys
    ADD CONSTRAINT vjtm_vj_fkey FOREIGN KEY (vehicle_journey_id) REFERENCES "9eb5427c-9a67-40da-a9da-f04b8a2aa38b".vehicle_journeys(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict FAEtOn4XZOfM8LQhCmmHrTEYBigBdtjB1HTtTjY6JfzCMTxur1OnRcdzEvaedmc

